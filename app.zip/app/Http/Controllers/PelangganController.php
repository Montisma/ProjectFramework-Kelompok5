<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PelangganController extends Controller
{
    public function showStatus()
    {
        // Retrieve currently authenticated user
        $user = Auth::user();
    
        // Retrieve orders for the user with user name
        $data_pesanan = DB::table('pesanan')
            ->join('users', 'pesanan.user_id', '=', 'users.id')
            ->where('pesanan.user_id', $user->id)
            ->select('pesanan.*', 'users.name as user_name') // Select the name from users table
            ->get();
    
        return view('pelanggan.status', compact('user', 'data_pesanan'));
    }
    
}
