<?php

// app/Http/Controllers/Auth/CustomerAuthController.php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;

class CustomerAuthController extends Controller
{
    // Show the registration form
    public function showRegistrationForm()
    {
        return view('auth.register_customer');
    }

    // Handle the registration request
    public function register(Request $request)
    {
        $request->validate([
            'username' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:customers',
            'password' => 'required|string|min:8',
            'phone_number' => 'required|string|max:15',
        ]);

        $customer = Customer::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => $request->password, // password is hashed in the model
            'phone_number' => $request->phone_number,
        ]);

        // After registration, you might want to log in the customer
        // and redirect to a dashboard or home page.

        return redirect()->route('customer.dashboard');
    }
}
